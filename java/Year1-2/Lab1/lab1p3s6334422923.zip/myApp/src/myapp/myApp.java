/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;

import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author INatZ
 */
public class myApp {
    public static void main(String[] args){
        String str = "Hello, World!";
        str = str.replace('o','5');
        str = str.replace('e', 'o');
        str = str.replace('5', 'e');
        System.out.println(str);
      
    }
}
