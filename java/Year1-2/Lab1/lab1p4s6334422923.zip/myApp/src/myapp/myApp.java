/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;

import java.awt.Rectangle;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 *
 * @author INatZ
 */
public class myApp {
    public static void main(String[] args){
        GregorianCalendar today = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2000,Calendar.SEPTEMBER,6);
        // --- test Ajarn's input ---
        //today.set(2019, Calendar.JANUARY, 8);
        //myBirthday.set(1990, Calendar.MARCH, 12);
        today.add(Calendar.DAY_OF_MONTH,100);
        int day_of_week = today.get(Calendar.DAY_OF_WEEK);
        int day_of_m = today.get(Calendar.DAY_OF_MONTH);
        int month = today.get(Calendar.MONTH) + 1;
        int year = today.get(Calendar.YEAR);
        System.out.println(day_of_week + " " + day_of_m + " "+ month + " " + year);
        myBirthday.add(Calendar.DAY_OF_MONTH,10000);
        day_of_week = myBirthday.get(Calendar.DAY_OF_WEEK);
        day_of_m = myBirthday.get(Calendar.DAY_OF_MONTH);
        month = myBirthday.get(Calendar.MONTH) + 1;
        year = myBirthday.get(Calendar.YEAR);
        System.out.println(day_of_week + " " + day_of_m + " "+ month + " " + year);
        
    }
}
