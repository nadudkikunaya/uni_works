/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;

/**
 *
 * @author INatZ
 */
public class Rectangle {
    public static void main(String[] args) {
        double width=2, length=4.5;
        System.out.println("Area = " + width*length);
        System.out.println("Perimeter = " + (width*2 + length*2));
    }
}
