/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;

import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author INatZ
 */
public class myApp {
    public static void main(String[] args){
        Random rand = new Random();
        int x,y,h,w;
        Rectangle myrec1 = new Rectangle();
        Rectangle myrec2 = new Rectangle();
        for(int i=0;i<2;i++){
            do
            {
                x = rand.nextInt(51);
                y = rand.nextInt(51);
                h = rand.nextInt(51);
                w = rand.nextInt(51);
            }while(isZero(x,y,h,w));
            if(i==0){
                myrec1.setBounds(x, y, h, w);
                /*
                System.out.println("----- RAND ----------");
                System.out.println(myrec1.x + " " + myrec1.y + " " + myrec1.width + " " + myrec1.height);
                System.out.println("(" + myrec1.getMaxX() + "," + myrec1.getMaxY() + ")");
                System.out.println("(" + myrec1.getMaxX() + "," + myrec1.getMinY() + ")");
                System.out.println("(" + myrec1.getMinX() + "," + myrec1.getMaxY() + ")");
                System.out.println("(" + myrec1.getMinX() + "," + myrec1.getMinY() + ")");*/
            }
            else{
                myrec2.setBounds(x, y, h, w);
                /*System.out.println("----- RAND ----------");
                System.out.println(myrec2.x + " " + myrec2.y + " " + myrec2.width + " " + myrec2.height );
                System.out.println("(" + myrec2.getMaxX() + "," + myrec2.getMaxY() + ")");
                System.out.println("(" + myrec2.getMaxX() + "," + myrec2.getMinY() + ")");
                System.out.println("(" + myrec2.getMinX() + "," + myrec2.getMaxY() + ")");
                System.out.println("(" + myrec2.getMinX() + "," + myrec2.getMinY() + ")");*/
            }
        }
        System.out.println(myrec1);
        System.out.println(myrec2);
        Rectangle myrec3 = myrec1.intersection(myrec2);
        System.out.println("Is the intersected rectangle empty?:" + myrec3.isEmpty());

    }
    public static boolean isZero(int x, int y, int height, int width){
        if(x == 0 || y == 0 || height == 0 || width == 0)
            return true;
        return false;
    }
    
}
