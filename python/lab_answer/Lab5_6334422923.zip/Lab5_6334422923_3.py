# -*- coding: utf-8 -*-
"""
Created on Wed Sep 16 08:18:37 2020

@author: usci
"""

n = int(input("Number of students : "))
i = 0
while i<n:
    inp = input("Student "+str(i+1)+" : ")
    i += 1